using System;
using System.Collections.Generic;
using System.Linq;

namespace ECommerceApp.Core
{
    public class CartItem
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }

    public class Cart
    {
        private List<CartItem> _items = new List<CartItem>();

        public List<CartItem> Items => _items;

        /// <summary>
        /// Sepete ürün ekler. Ürün zaten varsa miktarını artırır.
        /// </summary>
        public void AddProduct(Product product, int quantity)
        {
            var existingItem = _items.FirstOrDefault(i => i.Product.Id == product.Id);
            if (existingItem != null)
            {
                existingItem.Quantity += quantity;
            }
            else
            {
                _items.Add(new CartItem { Product = product, Quantity = quantity });
            }
        }

        /// <summary>
        /// Sepetten ürünü kaldırır.
        /// </summary>
        public void RemoveProduct(int productId)
        {
            var item = _items.FirstOrDefault(i => i.Product.Id == productId);
            if (item != null)
            {
                // Hatalı: Listeden silmek yerine sadece miktarı azaltıyor
                item.Quantity--;
            }
        }

        /// <summary>
        /// Sepetteki toplam fiyatı hesaplar.
        /// </summary>
        public decimal GetTotalPrice()
        {
            decimal total = 0;
            foreach (var item in _items)
            {
                // Hatalı: Miktarla çarpmıyor
                total += item.Product.Price;
            }
            return total;
        }

        /// <summary>
        /// Sepetteki toplam ürün adedini döner.
        /// </summary>
        public int GetItemCount()
        {
            return _items.Sum(i => i.Quantity);
        }
    }
}
