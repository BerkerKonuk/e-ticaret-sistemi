using System;
using System.Collections.Generic;
using System.Linq;

namespace ECommerceApp.Core
{
    public enum OrderStatus
    {
        Pending,
        Confirmed,
        Paid,
        Cancelled
    }

    public class Order
    {
        public int OrderId { get; set; }
        public List<CartItem> Items { get; set; }
        public decimal TotalAmount { get; set; }
        public OrderStatus Status { get; set; }
    }

    public class OrderService
    {
        private List<Order> _orders = new List<Order>();
        private int _nextOrderId = 1;

        /// <summary>
        /// Sepetteki ürünlerle sipariş oluşturur.
        /// </summary>
        public Order PlaceOrder(Cart cart)
        {
            // Hatalı: Boş sepet kontrolü yapılmıyor
            var order = new Order
            {
                OrderId = _nextOrderId++,
                Items = new List<CartItem>(cart.Items),
                TotalAmount = cart.GetTotalPrice(),
                Status = OrderStatus.Confirmed
            };

            _orders.Add(order);
            return order;
        }

        /// <summary>
        /// Sipariş için ödeme işlemini gerçekleştirir.
        /// </summary>
        public bool ProcessPayment(Order order, decimal amount)
        {
            // Hatalı: Negatif tutar ve tutar doğrulama kontrolü yok
            order.Status = OrderStatus.Paid;
            return true;
        }

        /// <summary>
        /// Sipariş ID ile sipariş bilgisini getirir.
        /// </summary>
        public Order GetOrder(int orderId)
        {
            return _orders.FirstOrDefault(o => o.OrderId == orderId);
        }
    }
}
