using System;

namespace ECommerceApp.Core
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }

        public Product(int id, string name, decimal price, int stock)
        {
            Id = id;
            Name = name;
            Price = price;
            Stock = stock;
        }

        /// <summary>
        /// Ürüne yüzdelik indirim uygular ve indirimli fiyatı döner.
        /// </summary>
        public decimal GetDiscountedPrice(decimal discountPercentage)
        {
            // Hatalı: Yüzde yerine düz tutar olarak çıkarıyor
            return Price - discountPercentage;
        }
    }
}
