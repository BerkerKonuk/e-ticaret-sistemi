using System;
using ECommerceApp.Core;

namespace ECommerceApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== E-Ticaret Sistemi ===\n");

            // 1. Ürünler oluştur
            var urun1 = new Product(1, "Laptop", 15000m, 10);
            var urun2 = new Product(2, "Mouse", 500m, 50);
            var urun3 = new Product(3, "Klavye", 1000m, 30);

            Console.WriteLine("Ürünler:");
            Console.WriteLine($"  {urun1.Id}. {urun1.Name} - {urun1.Price} TL (Stok: {urun1.Stock})");
            Console.WriteLine($"  {urun2.Id}. {urun2.Name} - {urun2.Price} TL (Stok: {urun2.Stock})");
            Console.WriteLine($"  {urun3.Id}. {urun3.Name} - {urun3.Price} TL (Stok: {urun3.Stock})");

            // 2. Sepete ekle
            var sepet = new Cart();
            sepet.AddProduct(urun1, 1);
            sepet.AddProduct(urun2, 2);
            sepet.AddProduct(urun3, 1);

            Console.WriteLine($"\nSepet ({sepet.GetItemCount()} ürün):");
            foreach (var item in sepet.Items)
            {
                Console.WriteLine($"  {item.Product.Name} x{item.Quantity} = {item.Product.Price * item.Quantity} TL");
            }
            Console.WriteLine($"Toplam: {sepet.GetTotalPrice()} TL");

            // 3. Sipariş ver
            var orderService = new OrderService();
            var siparis = orderService.PlaceOrder(sepet);
            Console.WriteLine($"\nSipariş #{siparis.OrderId} oluşturuldu");
            Console.WriteLine($"Sipariş Durumu: {siparis.Status}");
            Console.WriteLine($"Sipariş Tutarı: {siparis.TotalAmount} TL");

            // 4. Ödeme yap
            var odemeBasarili = orderService.ProcessPayment(siparis, siparis.TotalAmount);
            Console.WriteLine($"\nÖdeme: {(odemeBasarili ? "Başarılı" : "Başarısız")}");
            Console.WriteLine($"Sipariş Durumu: {siparis.Status}");

            // ===================================================
            // BUG TESTLERİ - Hataları Göster
            // ===================================================
            Console.WriteLine("\n========================================");
            Console.WriteLine("       BUG TESTLERİ BAŞLIYOR");
            Console.WriteLine("========================================\n");

            int passed = 0;
            int failed = 0;

            // Test 1: White Box - İndirim hesaplama
            var testProduct = new Product(1, "Laptop", 200m, 10);
            var discounted = testProduct.GetDiscountedPrice(20);
            if (discounted == 160m)
            {
                Console.WriteLine("[PASS] Test 1 (White Box): İndirim hesaplama doğru");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 1 (White Box): İndirim hesaplama");
                Console.WriteLine($"       Beklenen: 160 TL  |  Dönen: {discounted} TL");
                Console.WriteLine("       Neden   : Yüzde hesabı yerine düz çıkarma yapılıyor");
                failed++;
            }
            Console.WriteLine();

            // Test 2: White Box - Toplam fiyat
            var testCart = new Cart();
            testCart.AddProduct(new Product(1, "Mouse", 50m, 100), 3);
            var total = testCart.GetTotalPrice();
            if (total == 150m)
            {
                Console.WriteLine("[PASS] Test 2 (White Box): Toplam fiyat doğru");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 2 (White Box): Toplam fiyat hesaplama");
                Console.WriteLine($"       Beklenen: 150 TL  |  Dönen: {total} TL");
                Console.WriteLine("       Neden   : Fiyat miktarla çarpılmıyor");
                failed++;
            }
            Console.WriteLine();

            // Test 3: White Box - Aynı ürün miktar güncelleme
            var testCart2 = new Cart();
            var testP = new Product(1, "Klavye", 100m, 50);
            testCart2.AddProduct(testP, 2);
            testCart2.AddProduct(testP, 3);
            if (testCart2.Items.Count == 1 && testCart2.Items[0].Quantity == 5)
            {
                Console.WriteLine("[PASS] Test 3 (White Box): Aynı ürün miktar güncelleme doğru");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 3 (White Box): Aynı ürün miktar güncelleme");
                Console.WriteLine($"       Beklenen: 1 satır, 5 adet  |  Dönen: {testCart2.Items.Count} satır");
                failed++;
            }
            Console.WriteLine();

            // Test 4: Black Box - Ürün oluşturma
            var testP2 = new Product(1, "Laptop", 15000m, 10);
            if (testP2.Id == 1 && testP2.Name == "Laptop" && testP2.Price == 15000m && testP2.Stock == 10)
            {
                Console.WriteLine("[PASS] Test 4 (Black Box): Ürün özellikleri doğru");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 4 (Black Box): Ürün özellikleri hatalı");
                failed++;
            }
            Console.WriteLine();

            // Test 5: Black Box - Ürün silme
            var testCart3 = new Cart();
            testCart3.AddProduct(new Product(1, "Mouse", 500m, 50), 1);
            testCart3.RemoveProduct(1);
            if (testCart3.Items.Count == 0)
            {
                Console.WriteLine("[PASS] Test 5 (Black Box): Ürün sepetten silindi");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 5 (Black Box): Ürün sepetten silinmedi");
                Console.WriteLine($"       Beklenen: 0 ürün  |  Dönen: {testCart3.Items.Count} ürün");
                Console.WriteLine("       Neden   : Ürün listeden silinmek yerine miktarı azaltılıyor");
                failed++;
            }
            Console.WriteLine();

            // Test 6: Black Box - Toplam adet
            var testCart4 = new Cart();
            testCart4.AddProduct(new Product(1, "Laptop", 15000m, 10), 1);
            testCart4.AddProduct(new Product(2, "Mouse", 500m, 50), 2);
            if (testCart4.GetItemCount() == 3)
            {
                Console.WriteLine("[PASS] Test 6 (Black Box): Toplam adet doğru");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 6 (Black Box): Toplam adet hatalı");
                Console.WriteLine($"       Beklenen: 3  |  Dönen: {testCart4.GetItemCount()}");
                failed++;
            }
            Console.WriteLine();

            // Test 7: Gray Box - Boş sepetle sipariş
            var testOS = new OrderService();
            var emptyCart = new Cart();
            bool threwException = false;
            try { testOS.PlaceOrder(emptyCart); }
            catch (InvalidOperationException) { threwException = true; }

            if (threwException)
            {
                Console.WriteLine("[PASS] Test 7 (Gray Box): Boş sepet kontrolü çalışıyor");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 7 (Gray Box): Boş sepetle sipariş verilebiliyor");
                Console.WriteLine("       Beklenen: InvalidOperationException fırlatılmalı");
                Console.WriteLine("       Dönen   : Hata yok, sipariş oluşturuldu");
                Console.WriteLine("       Neden   : Boş sepet kontrolü yapılmıyor");
                failed++;
            }
            Console.WriteLine();

            // Test 8: Gray Box - Negatif ödeme
            var testOS2 = new OrderService();
            var testCart5 = new Cart();
            testCart5.AddProduct(new Product(1, "Laptop", 15000m, 10), 1);
            var testOrder = testOS2.PlaceOrder(testCart5);
            var negResult = testOS2.ProcessPayment(testOrder, -500m);
            if (!negResult)
            {
                Console.WriteLine("[PASS] Test 8 (Gray Box): Negatif ödeme reddedildi");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 8 (Gray Box): Negatif ödeme kabul edildi");
                Console.WriteLine("       Beklenen: false  |  Dönen: true");
                Console.WriteLine("       Neden   : Negatif tutar kontrolü yapılmıyor");
                failed++;
            }
            Console.WriteLine();

            // Test 9: Gray Box - Yanlış tutar
            var testOS3 = new OrderService();
            var testCart6 = new Cart();
            testCart6.AddProduct(new Product(1, "Laptop", 15000m, 10), 1);
            var testOrder2 = testOS3.PlaceOrder(testCart6);
            var wrongResult = testOS3.ProcessPayment(testOrder2, 100m);
            if (!wrongResult)
            {
                Console.WriteLine("[PASS] Test 9 (Gray Box): Yanlış tutar reddedildi");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 9 (Gray Box): Yanlış tutar kabul edildi");
                Console.WriteLine("       Beklenen: false  |  Dönen: true");
                Console.WriteLine("       Neden   : Tutar doğrulama kontrolü yapılmıyor");
                failed++;
            }
            Console.WriteLine();

            // Test 10: Integration - Tam akış
            var testOS4 = new OrderService();
            var testCart7 = new Cart();
            testCart7.AddProduct(new Product(1, "Laptop", 15000m, 10), 1);
            var testOrder3 = testOS4.PlaceOrder(testCart7);
            var payResult = testOS4.ProcessPayment(testOrder3, testOrder3.TotalAmount);
            if (testOrder3.Status == OrderStatus.Paid && payResult)
            {
                Console.WriteLine("[PASS] Test 10 (Integration): Tam sipariş akışı çalışıyor");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 10 (Integration): Tam sipariş akışı hatalı");
                failed++;
            }
            Console.WriteLine();

            // Test 11: Integration - Toplam tutar doğruluğu
            var testOS5 = new OrderService();
            var testCart8 = new Cart();
            testCart8.AddProduct(new Product(1, "Mouse", 500m, 50), 2);
            testCart8.AddProduct(new Product(2, "Klavye", 1000m, 30), 1);
            var testOrder4 = testOS5.PlaceOrder(testCart8);
            if (testOrder4.TotalAmount == 2000m)
            {
                Console.WriteLine("[PASS] Test 11 (Integration): Sipariş tutarı doğru");
                passed++;
            }
            else
            {
                Console.WriteLine("[FAIL] Test 11 (Integration): Sipariş tutarı hatalı");
                Console.WriteLine($"       Beklenen: 2000 TL  |  Dönen: {testOrder4.TotalAmount} TL");
                Console.WriteLine("       Neden   : GetTotalPrice() miktarla çarpmıyor (zincirleme hata)");
                failed++;
            }
            Console.WriteLine();

            // Sonuç
            Console.WriteLine("\n========================================");
            Console.WriteLine($"  SONUÇ: {passed} PASS / {failed} FAIL (Toplam: {passed + failed})");
            Console.WriteLine("========================================");

            Console.WriteLine("\nÇıkmak için bir tuşa basın...");
            Console.ReadKey();
        }
    }
}
