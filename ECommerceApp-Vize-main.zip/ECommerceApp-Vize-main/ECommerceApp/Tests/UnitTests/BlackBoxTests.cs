using NUnit.Framework;
using ECommerceApp.Core;

namespace ECommerceApp.Tests.UnitTests
{
    /// <summary>
    /// Black Box Testler: Kodun iç yapısını bilmeden, sadece girdi-çıktı ile test edilir.
    /// Methodların ne yaptığı bilinir ama nasıl yaptığı bilinmez.
    /// </summary>
    [TestFixture]
    public class BlackBoxTests
    {
        /// <summary>
        /// Test 4: Ürün doğru özelliklerle oluşturulmalı.
        /// </summary>
        [Test]
        public void Product_DogruOzelliklerleOlusturulmali()
        {
            // Arrange & Act
            var product = new Product(1, "Laptop", 15000m, 10);

            // Assert
            Assert.That(product.Id, Is.EqualTo(1));
            Assert.That(product.Name, Is.EqualTo("Laptop"));
            Assert.That(product.Price, Is.EqualTo(15000m));
            Assert.That(product.Stock, Is.EqualTo(10));
        }

        /// <summary>
        /// Test 5: Sepetten ürün çıkarıldığında ürün tamamen kaldırılmalı.
        /// </summary>
        [Test]
        public void Cart_RemoveProduct_UrunTamamenKaldirilmali()
        {
            // Arrange
            var cart = new Cart();
            var product = new Product(1, "Mouse", 500m, 50);
            cart.AddProduct(product, 1);

            // Act
            cart.RemoveProduct(1);

            // Assert - Ürün sepetten tamamen silinmeli
            Assert.That(cart.Items.Count, Is.EqualTo(0));
        }

        /// <summary>
        /// Test 6: Sepete farklı ürünler eklendiğinde toplam adet doğru olmalı.
        /// </summary>
        [Test]
        public void Cart_AddProduct_ToplamAdetDogruOlmali()
        {
            // Arrange
            var cart = new Cart();
            var product1 = new Product(1, "Laptop", 15000m, 10);
            var product2 = new Product(2, "Mouse", 500m, 50);

            // Act
            cart.AddProduct(product1, 1);
            cart.AddProduct(product2, 2);

            // Assert - 1 + 2 = 3 adet
            Assert.That(cart.GetItemCount(), Is.EqualTo(3));
        }
    }
}
