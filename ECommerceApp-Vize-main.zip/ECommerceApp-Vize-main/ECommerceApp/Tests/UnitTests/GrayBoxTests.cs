using System;
using NUnit.Framework;
using ECommerceApp.Core;

namespace ECommerceApp.Tests.UnitTests
{
    /// <summary>
    /// Gray Box Testler: Kodun iç yapısı kısmen bilinerek yazılan testler.
    /// Sistemin iç durumu (state) ve dış davranışı birlikte test edilir.
    /// </summary>
    [TestFixture]
    public class GrayBoxTests
    {
        /// <summary>
        /// Test 7: Boş sepetle sipariş verilmemeli, hata fırlatmalı.
        /// </summary>
        [Test]
        public void PlaceOrder_BosSepet_HataFirlatmali()
        {
           
            var orderService = new OrderService();
            var emptyCart = new Cart();

           
            Assert.Throws<InvalidOperationException>(() => orderService.PlaceOrder(emptyCart));
        }

        /// <summary>
        /// Test 8: Negatif tutarla ödeme kabul edilmemeli.
        /// </summary>
        [Test]
        public void ProcessPayment_NegatifTutar_KabulEtmemeli()
        {
            
            var orderService = new OrderService();
            var cart = new Cart();
            cart.AddProduct(new Product(1, "Laptop", 15000m, 10), 1);
            var order = orderService.PlaceOrder(cart);

            
            var result = orderService.ProcessPayment(order, -500m);

            // Assert - Negatif tutar kabul edilmemeli
            Assert.That(result, Is.False);
        }

        /// <summary>
        /// Test 9: Sipariş tutarından farklı ödeme kabul edilmemeli.
        /// </summary>
        [Test]
        public void ProcessPayment_YanlisTutar_KabulEtmemeli()
        {
            
            var orderService = new OrderService();
            var cart = new Cart();
            cart.AddProduct(new Product(1, "Laptop", 15000m, 10), 1);
            var order = orderService.PlaceOrder(cart);

            // Act - Sipariş tutarından farklı ödeme
            var result = orderService.ProcessPayment(order, 100m);

            // Assert - Yanlış tutar kabul edilmemeli
            Assert.That(result, Is.False);
        }
    }
}
