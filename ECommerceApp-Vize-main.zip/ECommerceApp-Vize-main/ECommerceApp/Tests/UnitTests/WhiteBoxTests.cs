using NUnit.Framework;
using ECommerceApp.Core;

namespace ECommerceApp.Tests.UnitTests
{
    /// <summary>
    /// White Box Testler: Kodun iç yapısını bilerek yazılan testler.
    /// Methodların iç mantığı ve hesaplamaları doğrudan test edilir.
    /// </summary>
    [TestFixture]
    public class WhiteBoxTests
    {
        /// <summary>
        /// Test 1: Product.GetDiscountedPrice methodu yüzdelik indirimi doğru hesaplamalı.
        /// </summary>
        [Test]
        public void GetDiscountedPrice_YuzdelikIndirim_DogruHesaplamali()
        {
            // Arrange
            var product = new Product(1, "Laptop", 200m, 10);

            // Act
            var result = product.GetDiscountedPrice(20);

            // Assert - %20 indirim: 200 * 0.80 = 160 olmalı
            Assert.That(result, Is.EqualTo(160m));
        }

        /// <summary>
        /// Test 2: Cart.GetTotalPrice methodu miktarı fiyatla çarpmalı.
        /// </summary>
        [Test]
        public void Cart_GetTotalPrice_MiktarlaCarpmali()
        {
            // Arrange
            var cart = new Cart();
            var product = new Product(1, "Mouse", 50m, 100);
            cart.AddProduct(product, 3);

            // Act
            var total = cart.GetTotalPrice();

            // Assert - 50 * 3 = 150 olmalı
            Assert.That(total, Is.EqualTo(150m));
        }

        /// <summary>
        /// Test 3: Sepete aynı ürün tekrar eklendiğinde miktar güncellenmeli.
        /// </summary>
        [Test]
        public void Cart_AddProduct_AyniUrun_MiktarGuncellenmeli()
        {
            // Arrange
            var cart = new Cart();
            var product = new Product(1, "Klavye", 100m, 50);

            // Act
            cart.AddProduct(product, 2);
            cart.AddProduct(product, 3);

            // Assert
            Assert.That(cart.Items.Count, Is.EqualTo(1));
            Assert.That(cart.Items[0].Quantity, Is.EqualTo(5));
        }
    }
}
