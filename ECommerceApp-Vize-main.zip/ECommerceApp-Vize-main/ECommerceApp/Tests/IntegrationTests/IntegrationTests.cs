using NUnit.Framework;
using ECommerceApp.Core;

namespace ECommerceApp.Tests.IntegrationTests
{
    /// <summary>
    /// Integration Testler: Birden fazla bileşenin birlikte çalışmasını test eder.
    /// Product, Cart ve OrderService katmanları uçtan uca test edilir.
    /// </summary>
    [TestFixture]
    public class IntegrationTests
    {
        /// <summary>
        /// Test 10: Tam sipariş akışı - Ürün → Sepet → Sipariş → Ödeme
        /// </summary>
        [Test]
        public void TamSiparisAkisi_SiparisOlusturulupOdenmeli()
        {
            // Arrange - Ürün oluştur
            var product = new Product(1, "Laptop", 15000m, 10);

            // Act - Sepete ekle, sipariş ver, ödeme yap
            var cart = new Cart();
            cart.AddProduct(product, 1);

            var orderService = new OrderService();
            var order = orderService.PlaceOrder(cart);
            var paymentResult = orderService.ProcessPayment(order, order.TotalAmount);

            // Assert - Sipariş ödendi durumunda olmalı
            Assert.That(order.Status, Is.EqualTo(OrderStatus.Paid));
            Assert.That(paymentResult, Is.True);
        }

        /// <summary>
        /// Test 11: Birden fazla ürünle sipariş tutarı doğru hesaplanmalı.
        /// Mouse x2 (500) + Klavye x1 (1000) = Beklenen Toplam: 2000 TL
        /// </summary>
        [Test]
        public void SiparisTutari_BirdenFazlaUrun_DogruHesaplanmali()
        {
            // Arrange
            var product1 = new Product(1, "Mouse", 500m, 50);
            var product2 = new Product(2, "Klavye", 1000m, 30);

            // Act
            var cart = new Cart();
            cart.AddProduct(product1, 2);  // 500 * 2 = 1000
            cart.AddProduct(product2, 1);  // 1000 * 1 = 1000

            var orderService = new OrderService();
            var order = orderService.PlaceOrder(cart);

            // Assert - Beklenen: (500*2) + (1000*1) = 2000
            Assert.That(order.TotalAmount, Is.EqualTo(2000m));
        }
    }
}
