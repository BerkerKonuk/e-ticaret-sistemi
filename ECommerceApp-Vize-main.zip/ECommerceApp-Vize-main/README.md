# 🛒 E-Commerce App — Yazılım Test Projesi

> Bilerek hatalı (buggy) yazılmış bir e-ticaret sistemi üzerinde **4 farklı test yöntemi** ile hata tespiti yapan NUnit test projesi.

---

## 📌 Projenin Amacı

Bu proje, bir e-ticaret uygulamasındaki **kasıtlı olarak yerleştirilmiş hataların (bug)** farklı test teknikleriyle nasıl tespit edildiğini göstermek amacıyla geliştirilmiştir. Proje kapsamında;

- Ürün seçme, sepete ekleme, sipariş verme ve ödeme yapma akışı simüle edilmektedir.
- Sistemdeki **5 farklı bug**, yazılan **11 test senaryosu** ile yakalanmaktadır.
- Test sonuçları ve hata analizleri `RAPOR.md` dosyasında detaylı olarak açıklanmıştır.

---

## 🏗️ Proje Yapısı

```
ECommerceApp/
 ├── Core/
 │    ├── Product.cs            # Ürün sınıfı
 │    ├── Cart.cs               # Sepet sınıfı
 │    └── OrderService.cs       # Sipariş ve ödeme servisi
 │
 ├── Tests/
 │    ├── UnitTests/
 │    │    ├── WhiteBoxTests.cs  # White Box (Unit) testler
 │    │    ├── BlackBoxTests.cs  # Black Box testler
 │    │    └── GrayBoxTests.cs   # Gray Box testler
 │    ├── IntegrationTests/
 │    │    └── IntegrationTests.cs # Integration testler
 │    └── Tests.csproj
 │
 ├── ECommerceApp.csproj
 └── Program.cs                 # Ana uygulama + test çıktısı
```

---

## ⚙️ Teknolojiler

| Teknoloji | Sürüm |
|-----------|-------|
| **Dil** | C# |
| **Framework** | .NET 8.0 |
| **Test Framework** | NUnit 4.3.2 |
| **Test Adapter** | NUnit3TestAdapter 4.6.0 |
| **Test SDK** | Microsoft.NET.Test.Sdk 17.12.0 |
| **IDE** | Visual Studio 2022 |
| **İşletim Sistemi** | Windows |

---

## 🧪 Test Türleri

### 1. Unit Test — White Box 🔬
Kodun **iç yapısı bilinerek** yazılan testler. Method içindeki hesaplama mantığı doğrudan test edilir.

### 2. Black Box Test 📦
Kodun **iç yapısı bilinmeden**, sadece girdi ve çıktıya bakılarak yazılan testler.

### 3. Gray Box Test 🔍
Kodun iç yapısı **kısmen bilinerek** yazılan testler. Hem davranış hem de internal state kontrol edilir.

### 4. Integration Test 🔗
Birden fazla bileşenin (Product → Cart → OrderService) **birlikte çalışmasını** test eden uçtan uca testler.

---

## 📊 Test Sonuçları

| # | Test Adı | Tür | Sonuç |
|---|----------|-----|-------|
| 1 | `GetDiscountedPrice_YuzdelikIndirim_DogruHesaplamali` | White Box | ❌ FAIL |
| 2 | `Cart_GetTotalPrice_MiktarlaCarpmali` | White Box | ❌ FAIL |
| 3 | `Cart_AddProduct_AyniUrun_MiktarGuncellenmeli` | White Box | ✅ PASS |
| 4 | `Product_DogruOzelliklerleOlusturulmali` | Black Box | ✅ PASS |
| 5 | `Cart_RemoveProduct_UrunTamamenKaldirilmali` | Black Box | ❌ FAIL |
| 6 | `Cart_AddProduct_ToplamAdetDogruOlmali` | Black Box | ✅ PASS |
| 7 | `PlaceOrder_BosSepet_HataFirlatmali` | Gray Box | ❌ FAIL |
| 8 | `ProcessPayment_NegatifTutar_KabulEtmemeli` | Gray Box | ❌ FAIL |
| 9 | `ProcessPayment_YanlisTutar_KabulEtmemeli` | Gray Box | ❌ FAIL |
| 10 | `TamSiparisAkisi_SiparisOlusturulupOdenmeli` | Integration | ✅ PASS |
| 11 | `SiparisTutari_BirdenFazlaUrun_DogruHesaplanmali` | Integration | ❌ FAIL |

> **Toplam:** 11 test · ✅ 4 geçti · ❌ 7 başarısız

---

## 🐛 Tespit Edilen Buglar

| # | Dosya | Method | Hata |
|---|-------|--------|------|
| 1 | `Product.cs` | `GetDiscountedPrice()` | İndirim yüzdesi düz tutar olarak çıkarılıyor |
| 2 | `Cart.cs` | `GetTotalPrice()` | Toplam hesabında miktar ile çarpılmıyor |
| 3 | `Cart.cs` | `RemoveProduct()` | Ürün listeden silinmek yerine miktarı azaltılıyor |
| 4 | `OrderService.cs` | `PlaceOrder()` | Boş sepet kontrolü yapılmıyor |
| 5 | `OrderService.cs` | `ProcessPayment()` | Negatif tutar ve tutar doğrulama kontrolü yok |

---

## 🚀 Çalıştırma

### Programı Çalıştırma
```bash
dotnet run --project ECommerceApp/ECommerceApp.csproj
```

### Testleri Çalıştırma
```bash
dotnet test ECommerceApp/Tests/Tests.csproj
```

### Visual Studio ile
1. `ECommerceApp.sln` dosyasını açın
2. **F5** → Programı çalıştırır (demo + test çıktısı)
3. **Test → Test Explorer → Run All** → NUnit testlerini çalıştırır

---

## 📄 Rapor

Detaylı test raporu için → [`RAPOR.md`](RAPOR.md)
