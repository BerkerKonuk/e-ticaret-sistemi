# E-Ticaret Sistemi — Test Raporu

## Proje Bilgileri

| Alan | Değer |
|------|-------|
| **Proje** | E-Ticaret Uygulaması |
| **Dil** | C# |
| **Framework** | .NET 8.0 |
| **Test Framework** | NUnit 4.3.2 |
| **Test Adapter** | NUnit3TestAdapter 4.6.0 |
| **Toplam Test** | 11 |
| **Geçen (PASS)** | 4 |
| **Başarısız (FAIL)** | 7 |

---

## Proje Dosya Yapısı

```
ECommerceApp/
 ├── Core/
 │    ├── Product.cs
 │    ├── Cart.cs
 │    └── OrderService.cs
 │
 ├── Tests/
 │    ├── UnitTests/
 │    │    ├── WhiteBoxTests.cs
 │    │    ├── BlackBoxTests.cs
 │    │    └── GrayBoxTests.cs
 │    ├── IntegrationTests/
 │    │    └── IntegrationTests.cs
 │    └── Tests.csproj
 │
 ├── ECommerceApp.csproj
 └── Program.cs
```

---

## Test Sonuçları Özeti

| # | Test Adı | Tür | Sonuç |
|---|----------|-----|-------|
| 1 | GetDiscountedPrice_YuzdelikIndirim_DogruHesaplamali | White Box | ❌ FAIL |
| 2 | Cart_GetTotalPrice_MiktarlaCarpmali | White Box | ❌ FAIL |
| 3 | Cart_AddProduct_AyniUrun_MiktarGuncellenmeli | White Box | ✅ PASS |
| 4 | Product_DogruOzelliklerleOlusturulmali | Black Box | ✅ PASS |
| 5 | Cart_RemoveProduct_UrunTamamenKaldirilmali | Black Box | ❌ FAIL |
| 6 | Cart_AddProduct_ToplamAdetDogruOlmali | Black Box | ✅ PASS |
| 7 | PlaceOrder_BosSepet_HataFirlatmali | Gray Box | ❌ FAIL |
| 8 | ProcessPayment_NegatifTutar_KabulEtmemeli | Gray Box | ❌ FAIL |
| 9 | ProcessPayment_YanlisTutar_KabulEtmemeli | Gray Box | ❌ FAIL |
| 10 | TamSiparisAkisi_SiparisOlusturulupOdenmeli | Integration | ✅ PASS |
| 11 | SiparisTutari_BirdenFazlaUrun_DogruHesaplanmali | Integration | ❌ FAIL |

---

## ✅ Geçen Testler

### Test 3: Cart_AddProduct_AyniUrun_MiktarGuncellenmeli (White Box — PASS)

- **Dosya:** `Core/Cart.cs` → `AddProduct()` methodu
- **Açıklama:** Sepete aynı ürün iki kez eklendiğinde, yeni satır oluşturulmak yerine mevcut ürünün miktarı artırılıyor.
- **Sonuç:** `AddProduct()` bu işlemi doğru yapıyor — PASS.

---

### Test 4: Product_DogruOzelliklerleOlusturulmali (Black Box — PASS)

- **Dosya:** `Core/Product.cs` → Constructor
- **Açıklama:** `new Product(1, "Laptop", 15000m, 10)` çağrısında Id, Name, Price ve Stock alanlarının doğru atandığı kontrol ediliyor.
- **Sonuç:** Constructor hatasız çalışıyor — PASS.

---

### Test 6: Cart_AddProduct_ToplamAdetDogruOlmali (Black Box — PASS)

- **Dosya:** `Core/Cart.cs` → `GetItemCount()` methodu
- **Açıklama:** Sepete 1 adet Laptop + 2 adet Mouse eklendiğinde toplam adedi 3 olmalı.
- **Sonuç:** `GetItemCount()` doğru çalışıyor — PASS.

---

### Test 10: TamSiparisAkisi_SiparisOlusturulupOdenmeli (Integration — PASS)

- **Dosya:** `Core/OrderService.cs` → `PlaceOrder()` + `ProcessPayment()`
- **Açıklama:** Ürün → Sepet → Sipariş → Ödeme tam akışı test ediliyor. Sipariş durumunun `Paid` olması bekleniyor.
- **Sonuç:** Sipariş durumu `Paid` olarak güncelleniyor — PASS.

---

## ❌ Başarısız Testler ve Nedenleri

### Test 1: GetDiscountedPrice_YuzdelikIndirim_DogruHesaplamali (White Box — FAIL)

- **Dosya:** `Core/Product.cs` → `GetDiscountedPrice()` methodu
- **Beklenen:** 160 TL
- **Dönen:** 180 TL
- **Neden:** Method, indirim yüzdesini (20) düz tutar olarak fiyattan çıkarıyor: `200 - 20 = 180`. Doğrusu yüzde hesabı yapılmalı: `200 × (1 - 20/100) = 160`.
- **Hatalı Kod:** `return Price - discountPercentage;`
- **Doğru Kod:** `return Price * (1 - discountPercentage / 100m);`

---

### Test 2: Cart_GetTotalPrice_MiktarlaCarpmali (White Box — FAIL)

- **Dosya:** `Core/Cart.cs` → `GetTotalPrice()` methodu
- **Beklenen:** 150 TL
- **Dönen:** 50 TL
- **Neden:** Toplam hesaplanırken ürün fiyatı miktarla çarpılmıyor. 3 adet 50 TL ürün için `50 * 3 = 150` yerine sadece `50` döndürüyor.
- **Hatalı Kod:** `total += item.Product.Price;`
- **Doğru Kod:** `total += item.Product.Price * item.Quantity;`

---

### Test 5: Cart_RemoveProduct_UrunTamamenKaldirilmali (Black Box — FAIL)

- **Dosya:** `Core/Cart.cs` → `RemoveProduct()` methodu
- **Beklenen:** Sepette 0 ürün
- **Dönen:** Sepette 1 ürün (hâlâ listede, Quantity = 0)
- **Neden:** `RemoveProduct()` ürünü listeden silmek yerine miktarını 1 azaltıyor. Ürün `Quantity=0` hâliyle listede kalmaya devam ediyor.
- **Hatalı Kod:** `item.Quantity--;`
- **Doğru Kod:** `_items.Remove(item);`

---

### Test 7: PlaceOrder_BosSepet_HataFirlatmali (Gray Box — FAIL)

- **Dosya:** `Core/OrderService.cs` → `PlaceOrder()` methodu
- **Beklenen:** `InvalidOperationException` fırlatılmalı
- **Dönen:** Hata yok, boş sipariş oluşturuldu
- **Neden:** `PlaceOrder()` sepette hiç ürün olmasa bile sipariş oluşturuyor. Boş sepet kontrolü eksik.
- **Eksik Kod:**
```csharp
if (cart.Items.Count == 0)
    throw new InvalidOperationException("Sepet boş, sipariş verilemez.");
```

---

### Test 8: ProcessPayment_NegatifTutar_KabulEtmemeli (Gray Box — FAIL)

- **Dosya:** `Core/OrderService.cs` → `ProcessPayment()` methodu
- **Beklenen:** `false` (ödeme reddedilmeli)
- **Dönen:** `true` (ödeme kabul edildi)
- **Neden:** Method, negatif tutar kontrolü yapmıyor. -500 TL gibi geçersiz bir tutar bile ödeme olarak kabul ediliyor.
- **Eksik Kod:**
```csharp
if (amount <= 0)
    return false;
```

---

### Test 9: ProcessPayment_YanlisTutar_KabulEtmemeli (Gray Box — FAIL)

- **Dosya:** `Core/OrderService.cs` → `ProcessPayment()` methodu
- **Beklenen:** `false` (ödeme reddedilmeli)
- **Dönen:** `true` (ödeme kabul edildi)
- **Neden:** Method, ödeme tutarının sipariş tutarıyla eşleşip eşleşmediğini kontrol etmiyor. 15.000 TL'lik siparişe 100 TL ödeme yapılabiliyor.
- **Eksik Kod:**
```csharp
if (amount != order.TotalAmount)
    return false;
```

---

### Test 11: SiparisTutari_BirdenFazlaUrun_DogruHesaplanmali (Integration — FAIL)

- **Dosya:** `Core/Cart.cs` → `GetTotalPrice()` (zincirleme hata)
- **Beklenen:** 2000 TL
- **Dönen:** 1500 TL
- **Neden:** Bu integration testi, Product + Cart + OrderService'i birlikte test ediyor. Mouse×2 (500 TL) + Klavye×1 (1000 TL) → beklenen `(500×2) + (1000×1) = 2000 TL`. Ancak Test 2'deki `GetTotalPrice()` bug'ı nedeniyle miktar çarpılmadığından `500 + 1000 = 1500 TL` hesaplanıyor. Hata OrderService'e zincirleme yansıyor.

---

## Bulunan Bug Özeti

| # | Dosya | Method | Hata Açıklaması |
|---|-------|--------|-----------------|
| 1 | Product.cs | `GetDiscountedPrice()` | İndirim yüzdesi, düz tutar olarak çıkarılıyor |
| 2 | Cart.cs | `GetTotalPrice()` | Toplam fiyat hesabında miktar ile çarpılmıyor |
| 3 | Cart.cs | `RemoveProduct()` | Ürün listeden silinmek yerine miktarı azaltılıyor |
| 4 | OrderService.cs | `PlaceOrder()` | Boş sepet kontrolü yapılmıyor |
| 5 | OrderService.cs | `ProcessPayment()` | Negatif tutar ve tutar doğrulama kontrolü eksik |
